import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LandingPage from './pages/LandingPage';
import CreateStory from './pages/CreateStory';
import StoryPreview from './pages/StoryPreview';
import Dashboard from './pages/Dashboard';
import { StoryProvider } from './context/StoryContext';

function App() {
  return (
    <Router>
      <StoryProvider>
        <div className="flex flex-col min-h-screen bg-gray-50">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/create" element={<CreateStory />} />
              <Route path="/preview" element={<StoryPreview />} />
              <Route path="/dashboard" element={<Dashboard />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </StoryProvider>
    </Router>
  );
}

export default App;