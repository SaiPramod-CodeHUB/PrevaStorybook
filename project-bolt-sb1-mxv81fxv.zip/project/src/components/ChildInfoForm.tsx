import { useState, useEffect } from 'react';
import { useStory } from '../context/StoryContext';

const ChildInfoForm = () => {
  const { story, setChildName, setChildAge } = useStory();
  const [name, setName] = useState(story.childName || '');
  const [age, setAge] = useState<number | ''>(story.childAge || '');
  const [nameError, setNameError] = useState('');
  const [ageError, setAgeError] = useState('');

  useEffect(() => {
    // Update context when form changes
    if (name) setChildName(name);
    if (age !== '') setChildAge(age as number);
  }, [name, age, setChildName, setChildAge]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setName(value);
    
    if (!value.trim()) {
      setNameError("Child's name is required");
    } else if (value.length > 20) {
      setNameError("Name must be 20 characters or less");
    } else {
      setNameError('');
    }
  };

  const handleAgeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numValue = parseInt(value, 10);
    
    if (value === '') {
      setAge('');
      setAgeError("Child's age is required");
    } else if (isNaN(numValue)) {
      setAge('');
      setAgeError("Please enter a valid number");
    } else if (numValue < 1 || numValue > 12) {
      setAge(numValue);
      setAgeError("Age must be between 1 and 12");
    } else {
      setAge(numValue);
      setAgeError('');
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-sm">
      <div className="space-y-6">
        <div>
          <label htmlFor="childName" className="block text-sm font-medium text-gray-700">
            Child's Name
          </label>
          <div className="mt-1">
            <input
              type="text"
              id="childName"
              name="childName"
              value={name}
              onChange={handleNameChange}
              className={`block w-full rounded-md ${
                nameError ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-purple-500 focus:ring-purple-500'
              } shadow-sm focus:ring-2 transition duration-150`}
              placeholder="Enter child's name"
            />
          </div>
          {nameError && <p className="mt-1 text-sm text-red-600">{nameError}</p>}
          {!nameError && name && (
            <p className="mt-1 text-sm text-green-600">Great! This name will be used throughout the story.</p>
          )}
        </div>

        <div>
          <label htmlFor="childAge" className="block text-sm font-medium text-gray-700">
            Child's Age
          </label>
          <div className="mt-1">
            <input
              type="number"
              id="childAge"
              name="childAge"
              value={age}
              onChange={handleAgeChange}
              min="1"
              max="12"
              className={`block w-full rounded-md ${
                ageError ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-purple-500 focus:ring-purple-500'
              } shadow-sm focus:ring-2 transition duration-150`}
              placeholder="Age (1-12)"
            />
          </div>
          {ageError && <p className="mt-1 text-sm text-red-600">{ageError}</p>}
          {!ageError && age !== '' && (
            <p className="mt-1 text-sm text-green-600">We'll tailor the story to be age-appropriate.</p>
          )}
        </div>

        <div>
          <label htmlFor="additionalInfo" className="block text-sm font-medium text-gray-700">
            Additional Details (Optional)
          </label>
          <div className="mt-1">
            <textarea
              id="additionalInfo"
              name="additionalInfo"
              rows={3}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 focus:ring-2 transition duration-150"
              placeholder="Add any special details you'd like included in the story"
            ></textarea>
          </div>
          <p className="mt-1 text-xs text-gray-500">
            For example: favorite colors, animals, or special interests
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChildInfoForm;