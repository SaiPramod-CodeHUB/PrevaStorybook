import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useStory } from '../context/StoryContext';
import { Upload, X, Image } from 'lucide-react';

const PhotoUploader = () => {
  const { story, setChildPhoto } = useStory();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setChildPhoto(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  }, [setChildPhoto]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    maxFiles: 1,
    maxSize: 5242880, // 5MB
  });

  const removePhoto = () => {
    setChildPhoto(null);
  };

  return (
    <div className="max-w-md mx-auto">
      {!story.childPhoto ? (
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors duration-200 ${
            isDragActive ? 'border-purple-500 bg-purple-50' : 'border-gray-300 hover:border-purple-400'
          }`}
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center">
            <Upload className="h-12 w-12 text-gray-400" />
            <p className="mt-4 text-lg font-medium text-gray-900">
              Drag & drop a photo here
            </p>
            <p className="mt-2 text-sm text-gray-500">
              or click to select a file
            </p>
            <p className="mt-1 text-xs text-gray-400">
              JPG, PNG or GIF, up to 5MB
            </p>
          </div>
        </div>
      ) : (
        <div className="relative">
          <div className="rounded-lg overflow-hidden border-2 border-purple-400 shadow-sm">
            <img 
              src={story.childPhoto} 
              alt="Child" 
              className="w-full h-auto"
            />
          </div>
          <div className="absolute top-2 right-2">
            <button
              type="button"
              onClick={removePhoto}
              className="bg-white rounded-full p-1 shadow-sm border border-gray-200 hover:bg-red-50 hover:border-red-300 transition-colors duration-200"
            >
              <X className="h-5 w-5 text-gray-600 hover:text-red-600" />
            </button>
          </div>
          <p className="mt-4 text-sm text-center text-green-600 font-medium">
            Photo uploaded successfully!
          </p>
          <p className="mt-1 text-xs text-center text-gray-500">
            Click the X in the top right to remove and upload a different photo
          </p>
        </div>
      )}

      <div className="mt-8">
        <h3 className="text-lg font-medium text-gray-900 mb-2">Photo Tips</h3>
        <ul className="text-sm text-gray-600 space-y-2">
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-green-500">✓</div>
            <span className="ml-2">Use a clear, well-lit photo of your child's face</span>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-green-500">✓</div>
            <span className="ml-2">Make sure their face is centered and visible</span>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-green-500">✓</div>
            <span className="ml-2">Neutral expressions work best</span>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-red-500">✗</div>
            <span className="ml-2">Avoid photos with multiple people</span>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-red-500">✗</div>
            <span className="ml-2">Avoid photos with sunglasses or hats that cover the face</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default PhotoUploader;