import { useStory } from '../context/StoryContext';
import { Link } from 'react-router-dom';

interface TemplateCardProps {
  template: {
    id: string;
    title: string;
    description: string;
    coverImage: string;
    ageRange: string;
    pageCount: number;
  };
  onClick?: () => void;
  selectable?: boolean;
}

const TemplateCard = ({ template, onClick, selectable = false }: TemplateCardProps) => {
  const { story, setSelectedTemplate } = useStory();
  const isSelected = story.selectedTemplate?.id === template.id;

  const handleClick = () => {
    if (selectable) {
      setSelectedTemplate(template);
      if (onClick) onClick();
    } else {
      // Link to create page with pre-selected template
      if (onClick) onClick();
    }
  };

  return (
    <div 
      className={`
        rounded-lg overflow-hidden shadow-md bg-white transition duration-300 transform hover:-translate-y-1 
        ${selectable ? 'cursor-pointer' : ''}
        ${isSelected && selectable ? 'ring-2 ring-purple-600 scale-105' : ''}
      `}
      onClick={handleClick}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={template.coverImage} 
          alt={template.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-purple-600 text-white text-xs px-2 py-1 rounded-full">
          Ages {template.ageRange}
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-1">{template.title}</h3>
        <p className="text-sm text-gray-500 mb-2">{template.description}</p>
        <div className="flex justify-between items-center mt-4">
          <span className="text-xs text-gray-500">{template.pageCount} Pages</span>
          {!selectable && (
            <Link 
              to="/create" 
              className="text-sm font-medium text-purple-600 hover:text-purple-700"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedTemplate(template);
              }}
            >
              Select
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;