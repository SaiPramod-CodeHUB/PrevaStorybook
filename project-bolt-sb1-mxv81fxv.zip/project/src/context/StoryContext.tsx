import React, { createContext, useState, useContext } from 'react';

// Define interface for StoryTemplate
interface StoryTemplate {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  ageRange: string;
  pageCount: number;
}

// Define interface for story creation state
interface StoryState {
  childPhoto: string | null;
  selectedTemplate: StoryTemplate | null;
  childName: string;
  childAge: number | null;
  currentStep: number;
  generatedPages: Array<{
    imageUrl: string;
    text: string;
  }>;
}

// Define interface for context
interface StoryContextType {
  story: StoryState;
  templates: StoryTemplate[];
  setChildPhoto: (photo: string | null) => void;
  setSelectedTemplate: (template: StoryTemplate | null) => void;
  setChildName: (name: string) => void;
  setChildAge: (age: number | null) => void;
  setCurrentStep: (step: number) => void;
  resetStory: () => void;
}

// Create context with default values
const StoryContext = createContext<StoryContextType>({
  story: {
    childPhoto: null,
    selectedTemplate: null,
    childName: '',
    childAge: null,
    currentStep: 1,
    generatedPages: [],
  },
  templates: [],
  setChildPhoto: () => {},
  setSelectedTemplate: () => {},
  setChildName: () => {},
  setChildAge: () => {},
  setCurrentStep: () => {},
  resetStory: () => {},
});

// Sample template data
const sampleTemplates: StoryTemplate[] = [
  {
    id: 'astronaut',
    title: 'Space Explorer',
    description: 'Journey through the stars as a brave astronaut, discovering new planets and meeting friendly aliens!',
    coverImage: 'https://images.pexels.com/photos/2156/sky-earth-space-working.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ageRange: '4-8',
    pageCount: 12,
  },
  {
    id: 'princess',
    title: 'Royal Adventure',
    description: 'Enter an enchanted kingdom where you become royalty and embark on a magical quest!',
    coverImage: 'https://images.pexels.com/photos/3865908/pexels-photo-3865908.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ageRange: '3-7',
    pageCount: 10,
  },
  {
    id: 'superhero',
    title: 'Superhero Quest',
    description: 'Discover your super powers and save the day in this action-packed adventure!',
    coverImage: 'https://images.pexels.com/photos/5439508/pexels-photo-5439508.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ageRange: '4-10',
    pageCount: 14,
  },
  {
    id: 'safari',
    title: 'Jungle Safari',
    description: 'Explore the wild jungle and make friends with amazing animals on this safari adventure!',
    coverImage: 'https://images.pexels.com/photos/847393/pexels-photo-847393.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ageRange: '3-8',
    pageCount: 10,
  },
];

// Create provider component
export const StoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [story, setStory] = useState<StoryState>({
    childPhoto: null,
    selectedTemplate: null,
    childName: '',
    childAge: null,
    currentStep: 1,
    generatedPages: [],
  });

  // For demo purposes, generate some sample pages when a template is selected
  const generateSamplePages = (template: StoryTemplate) => {
    const samplePages = [];
    const baseImageUrl = 'https://images.pexels.com/photos/';
    const spaceImages = ['2156/sky-earth-space-working.jpg', '41162/space-earth-galaxy-universe.jpg', '73910/stars-space-dark-galaxy.jpg'];
    const princessImages = ['3865908/pexels-photo-3865908.jpeg', '4677138/pexels-photo-4677138.jpeg', '4677141/pexels-photo-4677141.jpeg'];
    const superheroImages = ['5439508/pexels-photo-5439508.jpeg', '7813948/pexels-photo-7813948.jpeg', '5439501/pexels-photo-5439501.jpeg'];
    const safariImages = ['847393/pexels-photo-847393.jpeg', '39504/leopard-safari-africa-african.jpg', '4194849/pexels-photo-4194849.jpeg'];
    
    let images: string[] = [];
    
    if (template.id === 'astronaut') images = spaceImages;
    else if (template.id === 'princess') images = princessImages;
    else if (template.id === 'superhero') images = superheroImages;
    else if (template.id === 'safari') images = safariImages;
    
    for (let i = 0; i < 3; i++) {
      samplePages.push({
        imageUrl: baseImageUrl + images[i % images.length] + '?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        text: `This is sample text for page ${i + 1} of the ${template.title} storybook.`,
      });
    }
    
    return samplePages;
  };

  const setChildPhoto = (photo: string | null) => {
    setStory({ ...story, childPhoto: photo });
  };

  const setSelectedTemplate = (template: StoryTemplate | null) => {
    const generatedPages = template ? generateSamplePages(template) : [];
    setStory({ 
      ...story, 
      selectedTemplate: template,
      generatedPages
    });
  };

  const setChildName = (name: string) => {
    setStory({ ...story, childName: name });
  };

  const setChildAge = (age: number | null) => {
    setStory({ ...story, childAge: age });
  };

  const setCurrentStep = (step: number) => {
    setStory({ ...story, currentStep: step });
  };

  const resetStory = () => {
    setStory({
      childPhoto: null,
      selectedTemplate: null,
      childName: '',
      childAge: null,
      currentStep: 1,
      generatedPages: [],
    });
  };

  return (
    <StoryContext.Provider
      value={{
        story,
        templates: sampleTemplates,
        setChildPhoto,
        setSelectedTemplate,
        setChildName,
        setChildAge,
        setCurrentStep,
        resetStory,
      }}
    >
      {children}
    </StoryContext.Provider>
  );
};

// Create custom hook for using the context
export const useStory = () => useContext(StoryContext);