import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStory } from '../context/StoryContext';
import TemplateCard from '../components/TemplateCard';
import PhotoUploader from '../components/PhotoUploader';
import ChildInfoForm from '../components/ChildInfoForm';
import { CheckCircle2, Circle, AlertCircle } from 'lucide-react';

const CreateStory = () => {
  const navigate = useNavigate();
  const { story, setCurrentStep } = useStory();
  const [isNextDisabled, setIsNextDisabled] = useState(true);

  // Check if current step is completed
  useEffect(() => {
    switch (story.currentStep) {
      case 1: // Upload photo
        setIsNextDisabled(!story.childPhoto);
        break;
      case 2: // Select template
        setIsNextDisabled(!story.selectedTemplate);
        break;
      case 3: // Child info
        setIsNextDisabled(!story.childName || !story.childAge);
        break;
      default:
        setIsNextDisabled(false);
    }
  }, [story]);

  const handleNext = () => {
    if (story.currentStep < 4) {
      setCurrentStep(story.currentStep + 1);
    } else {
      navigate('/preview');
    }
  };

  const handleBack = () => {
    if (story.currentStep > 1) {
      setCurrentStep(story.currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (story.currentStep) {
      case 1:
        return <PhotoUploader />;
      case 2:
        return (
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {useStory().templates.map((template) => (
              <TemplateCard 
                key={template.id}
                template={template}
                selectable
              />
            ))}
          </div>
        );
      case 3:
        return <ChildInfoForm />;
      case 4:
        return (
          <div className="text-center bg-white p-8 rounded-lg shadow-sm">
            <div className="flex items-center justify-center mb-4">
              <AlertCircle className="h-12 w-12 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Ready to Create Your Storybook!</h3>
            <p className="text-gray-600 mb-6">
              We've got everything we need to create a beautiful, personalized storybook for {story.childName}.
              Click "Preview Story" to see how your storybook will look!
            </p>
            <div className="mt-4 bg-purple-50 p-4 rounded-lg">
              <h4 className="font-semibold text-purple-800 mb-2">Summary</h4>
              <ul className="text-left text-sm text-gray-600 space-y-2">
                <li>Child's name: <span className="font-medium">{story.childName}</span></li>
                <li>Age: <span className="font-medium">{story.childAge} years</span></li>
                <li>Story theme: <span className="font-medium">{story.selectedTemplate?.title}</span></li>
                <li>Photo uploaded: <span className="font-medium">Yes</span></li>
              </ul>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      {/* Progress indicator */}
      <div className="max-w-xl mx-auto mb-12">
        <div className="flex items-center justify-between">
          <div className="step flex flex-col items-center">
            <div className={`${story.currentStep >= 1 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500'} h-10 w-10 rounded-full flex items-center justify-center`}>
              {story.currentStep > 1 ? <CheckCircle2 className="h-6 w-6" /> : 1}
            </div>
            <p className="mt-2 text-sm font-medium text-gray-900">Photo</p>
          </div>
          <div className={`flex-1 h-1 ${story.currentStep > 1 ? 'bg-purple-600' : 'bg-gray-200'}`}></div>
          
          <div className="step flex flex-col items-center">
            <div className={`${story.currentStep >= 2 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500'} h-10 w-10 rounded-full flex items-center justify-center`}>
              {story.currentStep > 2 ? <CheckCircle2 className="h-6 w-6" /> : 2}
            </div>
            <p className="mt-2 text-sm font-medium text-gray-900">Theme</p>
          </div>
          <div className={`flex-1 h-1 ${story.currentStep > 2 ? 'bg-purple-600' : 'bg-gray-200'}`}></div>
          
          <div className="step flex flex-col items-center">
            <div className={`${story.currentStep >= 3 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500'} h-10 w-10 rounded-full flex items-center justify-center`}>
              {story.currentStep > 3 ? <CheckCircle2 className="h-6 w-6" /> : 3}
            </div>
            <p className="mt-2 text-sm font-medium text-gray-900">Info</p>
          </div>
          <div className={`flex-1 h-1 ${story.currentStep > 3 ? 'bg-purple-600' : 'bg-gray-200'}`}></div>
          
          <div className="step flex flex-col items-center">
            <div className={`${story.currentStep >= 4 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500'} h-10 w-10 rounded-full flex items-center justify-center`}>
              4
            </div>
            <p className="mt-2 text-sm font-medium text-gray-900">Create</p>
          </div>
        </div>
      </div>

      {/* Step heading */}
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
          {story.currentStep === 1 && "Upload Your Child's Photo"}
          {story.currentStep === 2 && "Choose a Story Theme"}
          {story.currentStep === 3 && "Tell Us About Your Child"}
          {story.currentStep === 4 && "Ready to Create Your Storybook"}
        </h1>
        <p className="mt-4 text-lg text-gray-500">
          {story.currentStep === 1 && "Upload a clear photo of your child's face for the best results."}
          {story.currentStep === 2 && "Select from our collection of exciting story templates."}
          {story.currentStep === 3 && "Help us personalize the story for your child."}
          {story.currentStep === 4 && "Review your selections and create your personalized storybook."}
        </p>
      </div>

      {/* Step content */}
      <div className="max-w-5xl mx-auto mb-12">
        {renderStepContent()}
      </div>

      {/* Navigation buttons */}
      <div className="max-w-xl mx-auto flex justify-between">
        <button
          type="button"
          onClick={handleBack}
          disabled={story.currentStep === 1}
          className={`px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium ${
            story.currentStep === 1 
              ? 'text-gray-400 bg-gray-100 cursor-not-allowed' 
              : 'text-gray-700 bg-white hover:bg-gray-50'
          } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200`}
        >
          Back
        </button>
        <button
          type="button"
          onClick={handleNext}
          disabled={isNextDisabled}
          className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium ${
            isNextDisabled 
              ? 'bg-purple-300 cursor-not-allowed' 
              : 'bg-purple-600 hover:bg-purple-700'
          } text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200`}
        >
          {story.currentStep < 4 ? 'Next' : 'Preview Story'}
        </button>
      </div>
    </div>
  );
};

export default CreateStory;