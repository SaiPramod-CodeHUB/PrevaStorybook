import { Link } from 'react-router-dom';
import { BookOpen, SparkleIcon, WandIcon as MagicWandIcon, CameraIcon, PuzzleIcon } from 'lucide-react';
import { useStory } from '../context/StoryContext';
import TemplateCard from '../components/TemplateCard';

const LandingPage = () => {
  const { templates } = useStory();

  return (
    <div>
      {/* Hero section */}
      <section className="relative bg-gradient-to-b from-purple-600 to-purple-800 text-white">
        <div className="max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
              Create Magical Personalized Storybooks For Your Child
            </h1>
            <p className="mt-6 text-xl max-w-3xl">
              Transform your child into the star of their own storybook adventure! 
              Upload their photo and watch as they become characters in beautifully 
              illustrated stories.
            </p>
            <div className="mt-10">
              <Link
                to="/create"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-purple-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200"
              >
                Create Your Story
              </Link>
              <Link
                to="/dashboard"
                className="ml-4 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-700 bg-opacity-60 hover:bg-opacity-70 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200"
              >
                View Examples
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/256431/pexels-photo-256431.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center mix-blend-overlay opacity-20"></div>
      </section>

      {/* How it works section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              How It Works
            </h2>
            <p className="mt-4 text-lg text-gray-500 max-w-2xl mx-auto">
              Create a personalized storybook starring your child in just a few easy steps!
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              <div className="bg-purple-50 rounded-lg p-6 text-center transform transition duration-500 hover:scale-105">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-md bg-purple-600 text-white">
                  <CameraIcon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Upload a Photo</h3>
                <p className="mt-2 text-base text-gray-500">
                  Upload a clear photo of your child's face that will be used to create personalized illustrations.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 text-center transform transition duration-500 hover:scale-105">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-md bg-purple-600 text-white">
                  <BookOpen className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Choose a Story</h3>
                <p className="mt-2 text-base text-gray-500">
                  Select from our collection of exciting story themes, from space adventures to magical kingdoms.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 text-center transform transition duration-500 hover:scale-105">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-md bg-purple-600 text-white">
                  <SparkleIcon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Enjoy Your Creation</h3>
                <p className="mt-2 text-base text-gray-500">
                  Our AI technology creates a unique storybook that you can download or order as a printed book.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured templates */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Featured Storybook Templates
            </h2>
            <p className="mt-4 text-lg text-gray-500 max-w-2xl mx-auto">
              Choose from our collection of beautifully designed storybook templates.
            </p>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {templates.map((template) => (
              <TemplateCard 
                key={template.id}
                template={template}
                onClick={() => {}}
              />
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              to="/create"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200"
            >
              Start Creating
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              What Parents Are Saying
            </h2>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-3">
            <div className="bg-purple-50 rounded-lg p-6 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-purple-200 flex items-center justify-center text-purple-600 font-bold">
                  JD
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold">Jessica D.</h4>
                  <p className="text-gray-500">Mother of two</p>
                </div>
              </div>
              <p className="text-gray-700">
                "My daughter absolutely loves seeing herself as the hero in her own space adventure! The illustrations are beautiful and the story was engaging for both of us."
              </p>
            </div>

            <div className="bg-purple-50 rounded-lg p-6 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-purple-200 flex items-center justify-center text-purple-600 font-bold">
                  MT
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold">Michael T.</h4>
                  <p className="text-gray-500">Father of one</p>
                </div>
              </div>
              <p className="text-gray-700">
                "This has become our favorite bedtime routine. My son gets so excited to see himself in the story, and it's helped him develop a love for reading."
              </p>
            </div>

            <div className="bg-purple-50 rounded-lg p-6 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-purple-200 flex items-center justify-center text-purple-600 font-bold">
                  AS
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold">Amanda S.</h4>
                  <p className="text-gray-500">Aunt</p>
                </div>
              </div>
              <p className="text-gray-700">
                "I created a storybook for my niece's birthday, and it was the perfect personalized gift. The process was easy and the quality of the printed book exceeded my expectations."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative bg-purple-700">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to create a magical story?</span>
            <span className="block text-purple-200">Start your personalized storybook today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <Link
                to="/create"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-purple-700 bg-white hover:bg-purple-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;