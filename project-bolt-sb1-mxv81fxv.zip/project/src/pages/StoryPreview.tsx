import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStory } from '../context/StoryContext';
import { ChevronLeft, ChevronRight, Download, ShoppingCart, Heart, Share2 } from 'lucide-react';
import { jsPDF } from 'jspdf';

const StoryPreview = () => {
  const navigate = useNavigate();
  const { story, resetStory } = useStory();
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if no story is selected
  if (!story.selectedTemplate || !story.childPhoto) {
    navigate('/create');
    return null;
  }

  const totalPages = story.generatedPages.length;

  const handlePreviousPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleDownload = async () => {
    setIsLoading(true);
    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Add cover page
      pdf.setFontSize(24);
      pdf.text(coverTitle, 20, 30);
      
      // Add story pages
      story.generatedPages.forEach((page, index) => {
        if (index > 0) pdf.addPage();
        
        // Add image
        const img = new Image();
        img.src = page.imageUrl;
        pdf.addImage(img, 'JPEG', 20, 20, 170, 120);
        
        // Add text
        pdf.setFontSize(12);
        const text = page.text.replace('[CHILD_NAME]', story.childName);
        pdf.text(text, 20, 150, { maxWidth: 170 });
        
        // Add page number
        pdf.setFontSize(10);
        pdf.text(`Page ${index + 1} of ${totalPages}`, 20, 280);
      });

      // Save the PDF
      pdf.save(`${coverTitle.toLowerCase().replace(/\s+/g, '-')}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('There was an error generating your PDF. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateNew = () => {
    resetStory();
    navigate('/create');
  };

  // Create a cover page that combines the template title and child's name
  const coverTitle = `${story.childName}'s ${story.selectedTemplate.title}`;

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900 sm:text-3xl">{coverTitle}</h1>
        <button
          onClick={handleCreateNew}
          className="px-4 py-2 text-sm font-medium text-purple-600 border border-purple-600 rounded-md hover:bg-purple-50 transition-colors duration-200"
        >
          Create New Story
        </button>
      </div>

      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        {/* Story viewer */}
        <div className="flex flex-col items-center p-8">
          {currentPage === 0 ? (
            // Cover page
            <div className="flex flex-col items-center">
              <div className="relative w-full max-w-2xl aspect-[3/4] rounded-lg overflow-hidden border-2 border-purple-200 shadow-md">
                <img 
                  src={story.selectedTemplate.coverImage} 
                  alt="Story cover" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6 text-white">
                  <h2 className="text-3xl font-bold">{coverTitle}</h2>
                  <p className="mt-2">A personalized adventure starring {story.childName}</p>
                </div>
              </div>
              <p className="mt-6 text-lg text-gray-600 text-center max-w-lg">
                Follow {story.childName} on an exciting adventure as they explore {story.selectedTemplate.title.toLowerCase()}!
              </p>
            </div>
          ) : (
            // Story pages
            <div className="flex flex-col items-center">
              <div className="w-full max-w-2xl aspect-[3/4] rounded-lg overflow-hidden border-2 border-purple-200 shadow-md">
                {/* Story image */}
                <div className="relative h-3/5 bg-gray-100">
                  <img 
                    src={story.generatedPages[currentPage - 1].imageUrl} 
                    alt={`Page ${currentPage}`} 
                    className="w-full h-full object-cover"
                  />
                  {/* Simulate the child's face being in the image */}
                  {story.childPhoto && (
                    <div className="absolute bottom-4 right-4 h-16 w-16 rounded-full overflow-hidden border-2 border-white shadow-md">
                      <img 
                        src={story.childPhoto} 
                        alt="Child" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
                {/* Story text */}
                <div className="h-2/5 p-6 bg-white">
                  <p className="text-gray-800 leading-relaxed">
                    {story.generatedPages[currentPage - 1].text.replace('[CHILD_NAME]', story.childName)}
                  </p>
                </div>
              </div>
              <p className="mt-4 text-sm text-gray-500">
                Page {currentPage} of {totalPages}
              </p>
            </div>
          )}

          {/* Page navigation */}
          <div className="flex items-center justify-center mt-8 space-x-4">
            <button
              onClick={handlePreviousPage}
              disabled={currentPage === 0}
              className={`p-2 rounded-full ${
                currentPage === 0 
                  ? 'text-gray-400 bg-gray-100 cursor-not-allowed' 
                  : 'text-purple-600 bg-purple-100 hover:bg-purple-200'
              } transition-colors duration-200`}
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            
            <div className="flex space-x-1">
              {Array.from({ length: totalPages + 1 }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentPage(index)}
                  className={`h-2 w-2 rounded-full transition-colors duration-200 ${
                    currentPage === index ? 'bg-purple-600' : 'bg-gray-300 hover:bg-purple-300'
                  }`}
                  aria-label={`Go to page ${index}`}
                ></button>
              ))}
            </div>
            
            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className={`p-2 rounded-full ${
                currentPage === totalPages 
                  ? 'text-gray-400 bg-gray-100 cursor-not-allowed' 
                  : 'text-purple-600 bg-purple-100 hover:bg-purple-200'
              } transition-colors duration-200`}
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-4 justify-center items-center px-8 py-6 bg-gray-50 border-t border-gray-200">
          <button
            onClick={handleDownload}
            disabled={isLoading}
            className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors duration-200"
          >
            {isLoading ? (
              <>
                <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                Processing...
              </>
            ) : (
              <>
                <Download className="h-5 w-5 mr-2" />
                Download PDF
              </>
            )}
          </button>
          
          <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors duration-200">
            <ShoppingCart className="h-5 w-5 mr-2" />
            Order Printed Book
          </button>
          
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100 transition-colors duration-200">
            <Heart className="h-5 w-5 mr-2 text-red-500" />
            Save to Favorites
          </button>
          
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100 transition-colors duration-200">
            <Share2 className="h-5 w-5 mr-2 text-blue-500" />
            Share
          </button>
        </div>
      </div>

      {/* Additional info section */}
      <div className="mt-12 bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">What happens next?</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Free PDF Download</h3>
            <p className="text-gray-600">
              Download a high-quality PDF of your personalized storybook right now. Perfect for digital reading or home printing.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Printed Book Option</h3>
            <p className="text-gray-600">
              Order a professionally printed, hardcover version of your storybook. Starting at $24.99 with worldwide shipping available.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryPreview;